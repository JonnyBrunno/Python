import random
import unicodedata

# ========FUNÇÃO PARA REMOVER ACENTOS=====
def remover_acentos(texto):
    return ''.join(
        c for c in unicodedata.normalize('NFKD', texto)
        if not unicodedata.combining(c)
    )


def jogo_forca():
    print("*********************")
    print("****JOGO DA FORCA****")
    print("*********************\n")
    
    # ========CATEGORIAS=========
    categorias = {
        "1": "Heróis da Marvel ou DC.txt",
        "2": "Filmes.txt",
        "3": "Paises.txt",
        "4": "Jogos.txt",
        "5": "Construção Civil.txt"
    }

    print("Escolha a categoria:")
    print("1 - Heróis da Marvel ou DC")
    print("2 - Filmes")
    print("3 - Países")
    print("4 - Jogos")
    print("5 - Construção Civil")

    escolha = input("Digite o número da categoria: ")

    while escolha not in categorias:
        escolha = input("Opção inválida. Digite novamente: ")

    nome_arquivo = categorias[escolha]

    # Abre o arquivo da categoria
    arquivo = open(nome_arquivo, "r", encoding="utf-8")

    palavras = []
    for linha in arquivo:
        palavras.append(linha.strip())

    arquivo.close()

    numero = random.randrange(0, len(palavras))

    # Palavra com acentos
    palavra_original = palavras[numero]

    # Palavra sem acentos para comparação
    palavra_normalizada = remover_acentos(palavra_original).lower()

    # Revela automaticamente símbolos
    letras_acertadas = [
        letra if (
            letra == " " or letra.isdigit() or letra in "-_:"
        ) else "_"
        for letra in palavra_original
    ]

    erros = 0
    acertou = False
    enforcou = False

    print(letras_acertadas)

    while not enforcou and not acertou:
        chute = input("Qual é seu chute? ").lower().strip()
        chute_normalizado = remover_acentos(chute)

        acertou_letra = chute_normalizado in palavra_normalizada

        if acertou_letra:
            for i, letra in enumerate(palavra_normalizada):
                if chute_normalizado == letra:
                    letras_acertadas[i] = palavra_original[i]
        else:
            erros += 1

        enforcou = erros == 5
        acertou = "_" not in letras_acertadas

        print(letras_acertadas)

        if acertou:
            print("Você é muito bom, parabéns!")
        else:
            if acertou_letra:
                print("Parabéns, acertou uma letra!")
            else:
                print(f"Você errou, tente novamente. Erro nº {erros}")

    print(f"\nFim de jogo, a palavra era: {palavra_original}")


# ======LOOP DO JOGO=======
while True:
    jogo_forca()

    continuar = input("\nDeseja jogar novamente? (s = sim / n = não): ").lower()

    if continuar in ["n", "nao", "não", "sair", "exit", "0", "q"]:
        print("\nObrigado por jogar! Até a próxima!")
        break
